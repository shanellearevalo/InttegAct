console.log("Hello, World!");
let name = "Student";
console.log("Welcome, " + name);